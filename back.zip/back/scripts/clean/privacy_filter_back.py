"""
개인정보 필터링 모듈 (순수 AI만 - 정규식 주석 처리)
"""

import re
from typing import Dict, List, Tuple

try:
    from presidio_analyzer import AnalyzerEngine
    from presidio_anonymizer import AnonymizerEngine

    PRESIDIO_AVAILABLE = True
except ImportError:
    PRESIDIO_AVAILABLE = False
    print("⚠️ Presidio 미설치. pip install presidio-analyzer presidio-anonymizer")

try:
    from transformers import pipeline

    TRANSFORMERS_AVAILABLE = True
except ImportError:
    TRANSFORMERS_AVAILABLE = False
    print("⚠️ Transformers 미설치. pip install transformers torch")


class PrivacyFilter:
    """AI 기반 민감정보 필터 (순수 AI만 사용 - 정규식 비활성화)"""

    def __init__(self, use_ner_model: bool = True, ner_model_name: str = None):
        """
        Args:
            use_ner_model: NER 모델 사용 여부 (기본: True)
            ner_model_name: 사용할 NER 모델명 (기본: 자동 선택)
        """
        self.use_presidio = PRESIDIO_AVAILABLE
        self.use_ner = use_ner_model and TRANSFORMERS_AVAILABLE
        self.ner_pipeline = None

        # 1. Presidio 초기화 (전화번호, 이메일, 신용카드 등)
        if self.use_presidio:
            print("✓ Presidio AI 필터 초기화 중...")
            try:
                self.analyzer = AnalyzerEngine()
                self.anonymizer = AnonymizerEngine()
                print("  ✓ Presidio 로드 완료")
            except Exception as e:
                print(f"  ⚠️ Presidio 로드 실패: {e}")
                self.use_presidio = False

        # 2. 한국어 NER 모델 초기화 (이름, 조직, 장소 등)
        if self.use_ner:
            print("✓ 한국어 NER 모델 초기화 중...")

            # 추천 모델 목록 (순서대로 시도)
            model_candidates = [
                ner_model_name,  # 사용자 지정
                "Leo97/KoELECTRA-small-v3-modu-ner",  # 가볍고 학습됨 (추천!) ⭐
                "monologg/koelectra-base-v3-finetuned-naver-ner",  # Naver NER (학습됨)
                "klue/roberta-base",  # 학습 안 됨 (사용 안 함)
            ]

            model_loaded = False
            for model_name_try in model_candidates:
                if model_name_try is None:
                    continue

                try:
                    print(f"  → 시도: {model_name_try}")
                    self.ner_pipeline = pipeline(
                        "ner", model=model_name_try, aggregation_strategy="simple"
                    )
                    print(f"  ✓ NER 모델 로드 완료: {model_name_try}")
                    model_loaded = True
                    break
                except Exception as e:
                    print(f"  ⚠️ 실패, 다음 모델 시도...")
                    continue

            if not model_loaded:
                print("  ⚠️ 모든 NER 모델 로드 실패")
                print(
                    "  💡 해결방법: python -c \"from transformers import pipeline; pipeline('ner', model='Leo97/KoELECTRA-small-v3-modu-ner')\""
                )
                self.use_ner = False

        # ============================================
        # 3. 정규식 패턴 - 전체 주석 처리 ⬇️
        # ============================================
        # self.basic_patterns = {
        #     "korean_phone": r"0\d{1,2}[-\s]?\d{3,4}[-\s]?\d{4}",  # 한국 전화번호
        #     "email": r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}",  # 이메일
        #     "korean_rrn": r"\d{6}[-\s]?\d{7}",  # 주민등록번호
        #     "business_number": r"\d{3}[-\s]?\d{2}[-\s]?\d{5}",  # 사업자번호
        # }

        print(f"\n📊 활성화된 필터:")
        print(f"  - Presidio: {'✓' if self.use_presidio else '✗'}")
        print(f"  - NER 모델: {'✓' if self.use_ner else '✗'}")
        print(f"  - 정규식 패턴: ✗ (주석 처리됨)")  # ← 변경

    def filter_text(self, text: str, confidence_threshold: float = 0.7) -> Dict:
        """
        텍스트에서 민감정보 자동 탐지 및 완전 삭제
        """
        if not text:
            return {
                "filtered_text": "",
                "found_items": [],
                "changes_made": False,
                "detection_methods": [],
            }

        print(f"\n    🔍 순수 AI 탐지 시작 (길이: {len(text)}자)")

        all_detections = []
        methods_used = []

        # 1. Presidio로 탐지
        if self.use_presidio:
            presidio_detections = self._detect_with_presidio(text)
            all_detections.extend(presidio_detections)
            if presidio_detections:
                methods_used.append("presidio")

        # 2. NER 모델로 탐지
        if self.use_ner:
            ner_detections = self._detect_with_ner(text, confidence_threshold)
            all_detections.extend(ner_detections)
            if ner_detections:
                methods_used.append("ner_model")

        # ============================================
        # 3. 정규식 패턴 탐지 - 주석 처리 ⬇️
        # ============================================
        # pattern_detections = self._detect_with_patterns(text)
        # all_detections.extend(pattern_detections)
        # if pattern_detections:
        #     methods_used.append("regex_patterns")

        # 4. 중복 제거 및 병합
        merged_detections = self._merge_detections(all_detections)

        # 5. 텍스트에서 삭제
        filtered_text = self._remove_detections(text, merged_detections)

        # 6. 공백 정리
        filtered_text = self._cleanup_whitespace(filtered_text)

        # 7. 결과 정리
        found_items = self._format_findings(merged_detections)

        if merged_detections:
            print(f"    ✅ 탐지 완료: {len(merged_detections)}개 항목 (순수 AI)")
            print(
                f"    📌 사용된 방법: {', '.join(methods_used) if methods_used else '없음'}"
            )
        else:
            print(f"    ℹ️ 민감정보 미발견")

        return {
            "filtered_text": filtered_text,
            "found_items": found_items,
            "changes_made": len(merged_detections) > 0,
            "detection_methods": methods_used,
        }

    def _detect_with_presidio(
        self, text: str
    ) -> List[Tuple[int, int, str, str, float]]:
        """Presidio로 탐지 (전화번호, 이메일, 신용카드 등)"""
        detections = []
        try:
            results = self.analyzer.analyze(
                text=text,
                language="en",  # 범용 패턴
                entities=[
                    "PHONE_NUMBER",
                    "EMAIL_ADDRESS",
                    "CREDIT_CARD",
                    "IBAN_CODE",
                    "US_SSN",
                    "DATE_TIME",
                ],
                return_decision_process=False,
            )

            for result in results:
                entity_text = text[result.start : result.end]
                detections.append(
                    (
                        result.start,
                        result.end,
                        entity_text,
                        result.entity_type,
                        float(result.score),  # float32 → float 변환
                    )
                )
                print(
                    f"      [Presidio] {result.entity_type}: {entity_text} ({result.score:.2f})"
                )

        except Exception as e:
            print(f"    ⚠️ Presidio 탐지 실패: {e}")

        return detections

    def _detect_with_ner(
        self, text: str, threshold: float
    ) -> List[Tuple[int, int, str, str, float]]:
        """NER 모델로 탐지 (이름, 조직, 장소 등)"""
        detections = []
        try:
            ner_results = self.ner_pipeline(text)

            for entity in ner_results:
                if entity["score"] >= threshold:
                    entity_type = self._map_ner_label(entity["entity_group"])

                    detections.append(
                        (
                            entity["start"],
                            entity["end"],
                            entity["word"],
                            entity_type,
                            float(entity["score"]),  # float32 → float 변환
                        )
                    )
                    print(
                        f"      [NER] {entity_type}: {entity['word']} ({entity['score']:.2f})"
                    )

        except Exception as e:
            print(f"    ⚠️ NER 탐지 실패: {e}")

        return detections

    # ============================================
    # 정규식 패턴 함수 - 주석 처리 ⬇️
    # ============================================
    # def _detect_with_patterns(
    #     self, text: str
    # ) -> List[Tuple[int, int, str, str, float]]:
    #     """최소한의 정규식 패턴으로 탐지"""
    #     detections = []
    #
    #     for pattern_name, pattern in self.basic_patterns.items():
    #         for match in re.finditer(pattern, text):
    #             detections.append(
    #                 (match.start(), match.end(), match.group(), pattern_name, 1.0)
    #             )
    #             print(f"      [패턴] {pattern_name}: {match.group()}")
    #
    #     return detections

    def _map_ner_label(self, label: str) -> str:
        """NER 레이블을 표준 타입으로 매핑"""
        label_map = {
            "PER": "PERSON",
            "PERSON": "PERSON",
            "PS": "PERSON",
            "LOC": "LOCATION",
            "LOCATION": "LOCATION",
            "LC": "LOCATION",
            "ORG": "ORGANIZATION",
            "ORGANIZATION": "ORGANIZATION",
            "OG": "ORGANIZATION",
            "DAT": "DATE",
            "DATE": "DATE",
            "DT": "DATE",
            "TIM": "TIME",
            "TIME": "TIME",
            "TI": "TIME",
        }
        return label_map.get(label.upper(), label)

    def _merge_detections(self, detections: List[Tuple]) -> List[Tuple]:
        """중복 탐지 병합"""
        if not detections:
            return []

        sorted_detections = sorted(detections, key=lambda x: (x[0], -x[1]))
        merged = []

        for detection in sorted_detections:
            start, end, text, entity_type, score = detection
            overlap = False

            for i, (m_start, m_end, m_text, m_type, m_score) in enumerate(merged):
                if start >= m_start and end <= m_end:
                    overlap = True
                    if score > m_score:
                        merged[i] = detection
                    break
                elif start < m_end and end > m_start:
                    overlap = True
                    if (end - start) > (m_end - m_start):
                        merged[i] = detection
                    break

            if not overlap:
                merged.append(detection)

        return merged

    def _remove_detections(self, text: str, detections: List[Tuple]) -> str:
        """탐지된 부분을 텍스트에서 제거"""
        sorted_detections = sorted(detections, key=lambda x: x[0], reverse=True)

        for start, end, _, _, _ in sorted_detections:
            text = text[:start] + text[end:]

        return text

    def _cleanup_whitespace(self, text: str) -> str:
        """공백 정리"""
        text = re.sub(r" {2,}", " ", text)
        text = re.sub(r" +\n", "\n", text)
        text = re.sub(r"\n +", "\n", text)
        text = re.sub(r"\n{3,}", "\n\n", text)

        lines = [line.strip() for line in text.split("\n")]
        return "\n".join(line for line in lines if line).strip()

    def _format_findings(self, detections: List[Tuple]) -> List[Dict]:
        """탐지 결과를 보고서 형식으로 변환"""
        findings_by_type = {}

        for _, _, text, entity_type, score in detections:
            if entity_type not in findings_by_type:
                findings_by_type[entity_type] = {"items": [], "scores": []}

            findings_by_type[entity_type]["items"].append(text)
            findings_by_type[entity_type]["scores"].append(score)

        result = []
        for entity_type, data in findings_by_type.items():
            avg_score = sum(data["scores"]) / len(data["scores"])
            result.append(
                {
                    "type": entity_type,
                    "count": len(data["items"]),
                    "examples": data["items"][:5],
                    "avg_confidence": round(avg_score, 3),
                    "method": "ai_only",  # ← 변경
                }
            )

        return result
